# Agora Django Video Call Starter

A simple django starter application for my video call implementation with Agora.
Link to the technical article can be found over here:
1. [Dev.to](https://dev.to/mupati/build-a-scalable-video-chat-app-with-agora-in-django-1lle)
2. [Medium](https://mupati.medium.com/build-a-scalable-video-chat-app-with-agora-in-django-f4ca7988d615)